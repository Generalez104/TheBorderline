Hai presente l'estenzione Mrbeastify? Ecco! Ora c'è la versione con il MrBeast italiano! Se vuoi creare una versione personalizzata (come ho fatto io) qui trovi il tutorial!: (https://github.com/MagicJinn/MrBeastify-Youtube/issues/16).

[Firefox]() | [Chrome]() | [Edge]() i link li metterò in futuro perché sex

Compatibile con tutti i browser! (Basati su sia su Firefox che su Chromium!).

Note:
* Questa estenzione è ispirata a Mrbeastify (https://chrome.google.com/webstore/detail/youtube-mrbeastify/dbmaeobgdodeimjdjnkipbfhgeldnmeb) e do tutti i crediti a lui!
* Ovviamente questa estenzione non è affiliata ai TheBorderline :)
